const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const connection = require('./db');

const app = express();

// MIDDLEWARE
app.use(cors());
app.use(bodyParser.json());

/* =========================
   CREATE CATEGORY
   ========================= */
app.post('/categories', (req, res) => {
  const { category_name, description } = req.body;

  if (!category_name || !description) {
    return res.status(400).send('All fields are required');
  }

  const sql =
    'INSERT INTO categories (category_name, description) VALUES (?, ?)';

  connection.query(sql, [category_name, description], (err, result) => {
    if (err) {
      console.error('Error inserting category:', err);
      return res.status(500).send('Server error');
    }

    res.status(201).json({
      message: 'Category added successfully',
      category_id: result.insertId
    });
  });
});

/* =========================
   READ ALL CATEGORIES
   ========================= */
app.get('/categories', (req, res) => {
  const sql = 'SELECT * FROM categories';

  connection.query(sql, (err, results) => {
    if (err) {
      console.error('Error fetching categories:', err);
      return res.status(500).send('Server error');
    }

    res.status(200).json(results);
  });
});

/* =========================
   READ SINGLE CATEGORY
   ========================= */
app.get('/categories/:category_id', (req, res) => {
  const { category_id } = req.params;

  const sql = 'SELECT * FROM categories WHERE category_id = ?';

  connection.query(sql, [category_id], (err, results) => {
    if (err) {
      console.error('Error fetching category:', err);
      return res.status(500).send('Server error');
    }

    if (results.length === 0) {
      return res.status(404).send('Category not found');
    }

    res.status(200).json(results[0]);
  });
});

/* =========================
   UPDATE CATEGORY
   ========================= */
app.put('/categories/:category_id', (req, res) => {
  const { category_id } = req.params;
  const { category_name, description } = req.body;

  if (!category_name || !description) {
    return res.status(400).send('All fields are required');
  }

  const sql =
    'UPDATE categories SET category_name = ?, description = ? WHERE category_id = ?';

  connection.query(sql, [category_name, description, category_id], (err, result) => {
    if (err) {
      console.error('Error updating category:', err);
      return res.status(500).send('Server error');
    }

    if (result.affectedRows === 0) {
      return res.status(404).send('Category not found');
    }

    res.status(200).send('Category updated successfully');
  });
});

/* =========================
   DELETE CATEGORY
   ========================= */
app.delete('/categories/:category_id', (req, res) => {
  const { category_id } = req.params;

  const sql = 'DELETE FROM categories WHERE category_id = ?';

  connection.query(sql, [category_id], (err, result) => {
    if (err) {
      console.error('Error deleting category:', err);
      return res.status(500).send('Server error');
    }

    if (result.affectedRows === 0) {
      return res.status(404).send('Category not found');
    }

    res.status(200).send('Category deleted successfully');
  });
});


/* =========================
   CREATE PRODUCT
========================= */
app.post('/products', (req, res) => {
    const { category_id, product_name, unit, price, image, status } = req.body;

    const sql = `
        INSERT INTO products
        (category_id, product_name, unit, price, image, status)
        VALUES (?, ?, ?, ?, ?, ?)
    `;

    connection.query(
        sql,
        [category_id, product_name, unit, price, image, status],
        (err, result) => {
            if (err) {
                return res.status(500).json(err);
            }
            res.status(201).json({
                message: 'Product added successfully',
                product_id: result.insertId
            });
        }
    );
});

/* =========================
   READ ALL PRODUCTS
========================= */
app.get('/products', (req, res) => {
    const sql = 'SELECT * FROM products';

    connection.query(sql, (err, result) => {
        if (err) {
            return res.status(500).json(err);
        }
        res.json(result);
    });
});

/* =========================
   READ SINGLE PRODUCT
========================= */
app.get('/products/:id', (req, res) => {
    const sql = 'SELECT * FROM products WHERE product_id = ?';

    connection.query(sql, [req.params.id], (err, result) => {
        if (err) {
            return res.status(500).json(err);
        }
        if (result.length === 0) {
            return res.status(404).json({ message: 'Product not found' });
        }
        res.json(result[0]);
    });
});

/* =========================
   UPDATE PRODUCT
========================= */
app.put('/products/:id', (req, res) => {
    const { product_name, unit, price, status } = req.body;

    const sql = `
        UPDATE products 
        SET product_name = ?, unit = ?, price = ?, status = ?
        WHERE product_id = ?
    `;

    connection.query(
        sql,
        [product_name, unit, price, status, req.params.id],
        (err, result) => {
            if (err) {
                return res.status(500).json(err);
            }
            if (result.affectedRows === 0) {
                return res.status(404).json({ message: 'Product not found' });
            }
            res.json({ message: 'Product updated successfully' });
        }
    );
});

/* =========================
   DELETE PRODUCT
========================= */
app.delete('/products/:id', (req, res) => {
    const sql = 'DELETE FROM products WHERE product_id = ?';

    connection.query(sql, [req.params.id], (err, result) => {
        if (err) {
            return res.status(500).json(err);
        }
        if (result.affectedRows === 0) {
            return res.status(404).json({ message: 'Product not found' });
        }
        res.json({ message: 'Product deleted successfully' });
    });
});



/* ============================
   CREATE CUSTOMER
============================ */
app.post('/customers', (req, res) => {
  const { customer_id, user_id, address, reward_points } = req.body;

  const query =
    'INSERT INTO customers (customer_id, user_id, address, reward_points) VALUES (?, ?, ?, ?)';

  connection.query(
    query,
    [customer_id, user_id, address, reward_points],
    (err) => {
      if (err) {
        console.error('Error creating customer:', err);
        res.status(500).send('Server error');
      } else {
        res.status(201).send('Customer added');
      }
    }
  );
});

/* ============================
   READ ALL CUSTOMERS
============================ */
app.get('/customers', (req, res) => {
  const query = 'SELECT * FROM customers';

  connection.query(query, (err, results) => {
    if (err) {
      console.error('Error fetching customers:', err);
      res.status(500).send('Server error');
    } else {
      res.status(200).json(results);
    }
  });
});

/* ============================
   READ SINGLE CUSTOMER
============================ */
app.get('/customers/:customer_id', (req, res) => {
  const { customer_id } = req.params;

  const query = 'SELECT * FROM customers WHERE customer_id = ?';

  connection.query(query, [customer_id], (err, results) => {
    if (err) {
      console.error('Error fetching customer:', err);
      res.status(500).send('Server error');
    } else if (results.length === 0) {
      res.status(404).send('Customer not found');
    } else {
      res.status(200).json(results[0]);
    }
  });
});

/* ============================
   UPDATE CUSTOMER
============================ */
app.put('/customers/:customer_id', (req, res) => {
  const { customer_id } = req.params;
  const { user_id, address, reward_points } = req.body;

  const query =
    'UPDATE customers SET user_id = ?, address = ?, reward_points = ? WHERE customer_id = ?';

  connection.query(
    query,
    [user_id, address, reward_points, customer_id],
    (err, results) => {
      if (err) {
        console.error('Error updating customer:', err);
        res.status(500).send('Server error');
      } else if (results.affectedRows === 0) {
        res.status(404).send('Customer not found');
      } else {
        res.status(200).send('Customer updated');
      }
    }
  );
});

/* ============================
   DELETE CUSTOMER
============================ */
app.delete('/customers/:customer_id', (req, res) => {
  const { customer_id } = req.params;

  const query = 'DELETE FROM customers WHERE customer_id = ?';

  connection.query(query, [customer_id], (err, results) => {
    if (err) {
      console.error('Error deleting customer:', err);
      res.status(500).send('Server error');
    } else if (results.affectedRows === 0) {
      res.status(404).send('Customer not found');
    } else {
      res.status(200).send('Customer deleted');
    }
  });
});


// CREATE student
app.post('/faqs', (req, res) => {
    const { faq_id, question, answer, status } = req.body;
    const sql = 'INSERT INTO faqs (faq_id, question, answer, status) VALUES (?, ?, ?, ?)';
    connection.query(sql, [faq_id, question, answer, status], (err) => {
        if (err) {
            res.status(500).json(err);
        } else {
            res.status(201).send('faq Added');
        }
    });
});

// READ all students
app.get('/faqs', (req, res) => {
    const sql = 'SELECT * FROM faqs';
    connection.query(sql, (err, result) => {
        if (err) {
            res.status(500).json(err);
        } else {
            res.json(result);
        }
    });
});

// READ single student
app.get('/faqs/:faq_id', (req, res) => {
    const sql = 'SELECT * FROM faqs WHERE faq_id = ?';
    connection.query(sql, [req.params.faq_id], (err, result) => {
        if (err) {
            res.status(500).json(err);
        } else if (result.length === 0) {
            res.status(404).send('faq Not Found');
        } else {
            res.json(result[0]);
        }
    });
});

// UPDATE student
app.put('/faqs/:faq_id', (req, res) => {
    const { question, answer, status } = req.body;
    const sql = 'UPDATE faqs SET question=?, answer=?, status=? WHERE faq_id=?';
    connection.query(sql, [question, answer, status, req.params.faq_id], (err, result) => {
        if (err) {
            res.status(500).json(err);
        } else if (result.affectedRows === 0) {
            res.status(404).send('faq Not Found');
        } else {
            res.send('faq');
        }
    });
});

// DELETE student
app.delete('/faqs/:faq_id', (req, res) => {
    const sql = 'DELETE FROM faqs WHERE faq_id=?';
    connection.query(sql, [req.params.faq_id], (err, result) => {
        if (err) {
            res.status(500).json(err);
        } else if (result.affectedRows === 0) {
            res.status(404).send('faq Not Found');
        } else {
            res.send('faq Deleted');
        }
    });
});

/*======================login===============*/
app.post('/users/login', (req, res) => {
  const { name, password } = req.body;

  // Validation
  if (!name || !password) {
    return res.status(400).send('Username and password are required');
  }

  const query = 'SELECT * FROM users WHERE name = ? AND password = ?';

  connection.query(query, [name, password], (err, results) => {
    if (err) {
      console.error('Error during login:', err);
      return res.status(500).send('Server error');
    }

    if (results.length === 0) {
      return res.status(401).send('Invalid username or password');
    }

    const user = results[0];

    res.status(200).json({
      message: 'Login successful',
      user: {
        user_id: user.user_id,
        name: user.name,
        email: user.email,
        mobile: user.mobile,
        role: user.role,
        status: user.status
      }
    });
  });
});


app.post('/users/register', (req, res) => {
  const { name, email, password, mobile, role, status } = req.body;

  // BASIC VALIDATION
  if (!name || !email || !password || !mobile) {
    return res.status(400).send('All required fields must be provided');
  }

  // CHECK IF USER ALREADY EXISTS (email or mobile)
  const checkQuery = 'SELECT user_id FROM users WHERE email = ? OR mobile = ?';

  connection.query(checkQuery, [email, mobile], (err, results) => {
    if (err) {
      console.error('Error checking user:', err);
      return res.status(500).send('Server error');
    }

    if (results.length > 0) {
      return res.status(409).send('User already exists');
    }

    // INSERT USER
    const insertQuery = `
      INSERT INTO users (name, email, password, mobile, role, status)
      VALUES (?, ?, ?, ?, ?, ?)
    `;

    connection.query(
      insertQuery,
      [
        name,
        email,
        password,          // ⚠️ plaintext (OK for student project only)
        mobile,
        role || 'user',    // default role
        status || 'active' // default status
      ],
      (err, result) => {
        if (err) {
          console.error('Error registering user:', err);
          return res.status(500).send('Server error');
        }

        res.status(201).json({
          message: 'User registered successfully',
          user_id: result.insertId
        });
      }
    );
  });
});

/* =====================================================
   ORDERS CRUD
===================================================== */

// CREATE ORDER
app.post('/orders', (req, res) => {
  const { user_id, order_date, total_amount, payment_mode, order_status } = req.body;

  const query = `
    INSERT INTO orders (user_id, order_date, total_amount, payment_mode, order_status)
    VALUES (?, ?, ?, ?, ?)
  `;

  connection.query(
    query,
    [user_id, order_date, total_amount, payment_mode, order_status],
    (err) => {
      if (err) {
        console.error('Error creating order:', err);
        res.status(500).send('Server error');
      } else {
        res.status(201).send('Order added');
      }
    }
  );
});

// READ ALL ORDERS
app.get('/orders', (req, res) => {
  connection.query('SELECT * FROM orders', (err, results) => {
    if (err) res.status(500).send('Server error');
    else res.status(200).json(results);
  });
});

// READ SINGLE ORDER
app.get('/orders/:order_id', (req, res) => {
  const { order_id } = req.params;

  connection.query(
    'SELECT * FROM orders WHERE order_id = ?',
    [order_id],
    (err, results) => {
      if (err) res.status(500).send('Server error');
      else if (results.length === 0) res.status(404).send('Order not found');
      else res.status(200).json(results[0]);
    }
  );
});

// UPDATE ORDER
app.put('/orders/:order_id', (req, res) => {
  const { order_id } = req.params;
  const { user_id, order_date, total_amount, payment_mode, order_status } = req.body;

  const query = `
    UPDATE orders
    SET user_id=?, order_date=?, total_amount=?, payment_mode=?, order_status=?
    WHERE order_id=?
  `;

  connection.query(
    query,
    [user_id, order_date, total_amount, payment_mode, order_status, order_id],
    (err, result) => {
      if (err) res.status(500).send('Server error');
      else if (result.affectedRows === 0) res.status(404).send('Order not found');
      else res.status(200).send('Order updated');
    }
  );
});

// DELETE ORDER
app.delete('/orders/:order_id', (req, res) => {
  connection.query(
    'DELETE FROM orders WHERE order_id = ?',
    [req.params.order_id],
    (err, result) => {
      if (err) res.status(500).send('Server error');
      else if (result.affectedRows === 0) res.status(404).send('Order not found');
      else res.status(200).send('Order deleted');
    }
  );
});

/* =====================================================
   ORDER_ITEMS CRUD
===================================================== */

app.post('/order-items', (req, res) => {
  const { order_id, product_id, quantity, price, subtotal } = req.body;

  const query = `
    INSERT INTO order_items (order_id, product_id, quantity, price, subtotal)
    VALUES (?, ?, ?, ?, ?)
  `;

  connection.query(
    query,
    [order_id, product_id, quantity, price, subtotal],
    (err) => {
      if (err) res.status(500).send('Server error');
      else res.status(201).send('Order item added');
    }
  );
});

app.get('/order-items', (req, res) => {
  connection.query('SELECT * FROM order_items', (err, results) => {
    if (err) res.status(500).send('Server error');
    else res.json(results);
  });
});

app.get('/order-items/:order_item_id', (req, res) => {
  connection.query(
    'SELECT * FROM order_items WHERE order_item_id = ?',
    [req.params.order_item_id],
    (err, results) => {
      if (err) res.status(500).send('Server error');
      else if (results.length === 0) res.status(404).send('Order item not found');
      else res.json(results[0]);
    }
  );
});

app.put('/order-items/:order_item_id', (req, res) => {
  const { order_id, product_id, quantity, price, subtotal } = req.body;

  const query = `
    UPDATE order_items
    SET order_id=?, product_id=?, quantity=?, price=?, subtotal=?
    WHERE order_item_id=?
  `;

  connection.query(
    query,
    [order_id, product_id, quantity, price, subtotal, req.params.order_item_id],
    (err, result) => {
      if (err) res.status(500).send('Server error');
      else if (result.affectedRows === 0) res.status(404).send('Order item not found');
      else res.send('Order item updated');
    }
  );
});

app.delete('/order-items/:order_item_id', (req, res) => {
  connection.query(
    'DELETE FROM order_items WHERE order_item_id=?',
    [req.params.order_item_id],
    (err, result) => {
      if (err) res.status(500).send('Server error');
      else if (result.affectedRows === 0) res.status(404).send('Order item not found');
      else res.send('Order item deleted');
    }
  );
});

/* =====================================================
   INVOICES CRUD
===================================================== */

app.post('/invoices', (req, res) => {
  const { order_id, invoice_date, invoice_pdf_path } = req.body;

  connection.query(
    'INSERT INTO invoices (order_id, invoice_date, invoice_pdf_path) VALUES (?, ?, ?)',
    [order_id, invoice_date, invoice_pdf_path],
    (err) => {
      if (err) res.status(500).send('Server error');
      else res.status(201).send('Invoice created');
    }
  );
});

app.get('/invoices', (req, res) => {
  connection.query('SELECT * FROM invoices', (err, results) => {
    if (err) res.status(500).send('Server error');
    else res.json(results);
  });
});

/* =====================================================
   REWARDS CRUD
===================================================== */

app.post('/rewards', (req, res) => {
  const { points, description, expiry_date } = req.body;

  connection.query(
    'INSERT INTO rewards (points, description, expiry_date) VALUES (?, ?, ?)',
    [points, description, expiry_date],
    (err) => {
      if (err) res.status(500).send('Server error');
      else res.status(201).send('Reward added');
    }
  );
});

app.get('/rewards', (req, res) => {
  connection.query('SELECT * FROM rewards', (err, results) => {
    if (err) res.status(500).send('Server error');
    else res.json(results);
  });
});

/* =====================================================
   CUSTOMER_REWARDS CRUD
===================================================== */

app.post('/customer-rewards', (req, res) => {
  const { customer_id, reward_id, used_status } = req.body;

  connection.query(
    'INSERT INTO customer_rewards (customer_id, reward_id, used_status) VALUES (?, ?, ?)',
    [customer_id, reward_id, used_status],
    (err) => {
      if (err) res.status(500).send('Server error');
      else res.status(201).send('Customer reward added');
    }
  );
});

app.get('/customer-rewards', (req, res) => {
  connection.query('SELECT * FROM customer_rewards', (err, results) => {
    if (err) res.status(500).send('Server error');
    else res.json(results);
  });
});

/* =====================================================
   NOTIFICATIONS CRUD
===================================================== */

app.post('/notifications', (req, res) => {
  const { user_id, message, status } = req.body;

  connection.query(
    'INSERT INTO notifications (user_id, message, status) VALUES (?, ?, ?)',
    [user_id, message, status],
    (err) => {
      if (err) res.status(500).send('Server error');
      else res.status(201).send('Notification sent');
    }
  );
});

app.get('/notifications', (req, res) => {
  connection.query('SELECT * FROM notifications', (err, results) => {
    if (err) res.status(500).send('Server error');
    else res.json(results);
  });
});

/* =====================================================
   CONTACT_MESSAGES CRUD
===================================================== */

app.post('/contact-messages', (req, res) => {
  const { name, email, message } = req.body;

  connection.query(
    'INSERT INTO contact_messages (name, email, message) VALUES (?, ?, ?)',
    [name, email, message],
    (err) => {
      if (err) res.status(500).send('Server error');
      else res.status(201).send('Message received');
    }
  );
});

app.get('/contact-messages', (req, res) => {
  connection.query('SELECT * FROM contact_messages', (err, results) => {
    if (err) res.status(500).send('Server error');
    else res.json(results);
  });
});

/* =========================
   SERVER
========================= */
app.listen(8000, () => {
  console.log('Server running on port 8000');
});
